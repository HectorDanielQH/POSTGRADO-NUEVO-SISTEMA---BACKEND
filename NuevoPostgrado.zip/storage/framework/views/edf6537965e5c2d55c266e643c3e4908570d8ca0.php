

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('plugins.Summernote', true); ?>
<?php $__env->startSection('content_header'); ?>
    
    <div class="container">
        <h1>Programas</h1>
        <a href="<?php echo e(route('programas.create')); ?>" class="btn btn-primary float-right">
            <i class="fas fa-plus"></i>
            Crear Programa</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('programas-live', [])->html();
} elseif ($_instance->childHasBeenRendered('gtjlvZC')) {
    $componentId = $_instance->getRenderedChildComponentId('gtjlvZC');
    $componentTag = $_instance->getRenderedChildComponentTagName('gtjlvZC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gtjlvZC');
} else {
    $response = \Livewire\Livewire::mount('programas-live', []);
    $html = $response->html();
    $_instance->logRenderedChild('gtjlvZC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/programas/index.blade.php ENDPATH**/ ?>