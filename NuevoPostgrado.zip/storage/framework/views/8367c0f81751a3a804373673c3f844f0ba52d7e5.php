

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('plugins.Summernote', true); ?>
<?php $__env->startSection('content_header'); ?>
    
    <div class="container">
        <h1>
            LISTA DE PARTICIPANTES DE:
            <br>
            <?php echo e($programa->nombrePrograma); ?>

        </h1>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="container">
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellido</th>
                <th scope="col">Cedula</th>
                <th scope="col">Telefono</th>
                <th scope="col">Correo</th>
                <th scope="col">Tipo</th>
                <th scope="col">Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($participante->nombres); ?></td>
                    <td><?php echo e($participante->apellidos); ?></td>
                    <td><?php echo e($participante->ci); ?></td>
                    <td><?php echo e($participante->celular); ?></td>
                    <td><?php echo e($participante->email); ?></td>
                    <td>
                        
                        <?php if($participante->tipo_participante == 1): ?>
                            <span class="badge badge-success"><?php echo e(__('Profesional')); ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger"><?php echo e(__('Estudiante')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form
                            action="<?php echo e(route('estudiantes.destroy', $participante->id)); ?>"
                            method="POST"
                            style="display: inline"
                        >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" onclick="return confirm('¿Estas seguro de eliminar este registro?')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">
                        <h3 class="text-center">No hay participantes registrados</h3>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/participantes/verlista.blade.php ENDPATH**/ ?>