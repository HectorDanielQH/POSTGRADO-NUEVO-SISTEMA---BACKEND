

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('plugins.Summernote', true); ?>
<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('facultades-live', [])->html();
} elseif ($_instance->childHasBeenRendered('YxlZhuc')) {
    $componentId = $_instance->getRenderedChildComponentId('YxlZhuc');
    $componentTag = $_instance->getRenderedChildComponentTagName('YxlZhuc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YxlZhuc');
} else {
    $response = \Livewire\Livewire::mount('facultades-live', []);
    $html = $response->html();
    $_instance->logRenderedChild('YxlZhuc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/facultades/index.blade.php ENDPATH**/ ?>