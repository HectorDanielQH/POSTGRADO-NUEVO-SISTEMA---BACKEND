

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('plugins.Summernote', true); ?>
<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('coordinadores-live', [])->html();
} elseif ($_instance->childHasBeenRendered('KczVOdQ')) {
    $componentId = $_instance->getRenderedChildComponentId('KczVOdQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('KczVOdQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KczVOdQ');
} else {
    $response = \Livewire\Livewire::mount('coordinadores-live', []);
    $html = $response->html();
    $_instance->logRenderedChild('KczVOdQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/coordinadores/index.blade.php ENDPATH**/ ?>