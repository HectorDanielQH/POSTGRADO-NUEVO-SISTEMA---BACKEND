<div>
    
    <div class="container">
        
        <div class="row my-3">
            <div class="col-12 d-flex justify-content-around align-items-center">
                <div class="col-4">
                    <span class="badge badge-primary">Mostrar</span>
                    <select wire:model="cant" class="form-control-sm">
                        <option value="5" <?php echo e($cant == 5 ? 'selected' : ''); ?> >5</option>
                        <option value="10" <?php echo e($cant==10? 'selected' : ''); ?> >10</option>
                        <option value="15" <?php echo e($cant==15? 'selected' : ''); ?> >15</option>
                        <option value="20" <?php echo e($cant==20? 'selected' : ''); ?> >20</option>
                    </select>
                    <span class="badge badge-primary">registros</span>
                </div>
                <?php if (isset($component)) { $__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Input::resolve(['name' => 'search','label' => 'Buscar Programa','fgroupClass' => 'col-4'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Buscar...','wire:model' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff)): ?>
<?php $component = $__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff; ?>
<?php unset($__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff); ?>
<?php endif; ?>
            </div>
        </div>
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Imagen de Afiche</th>
                <th scope="col">Estado</th>
                <th scope="col">Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($programa->nombrePrograma); ?></td>
                    <td>
                        <img src="<?php echo e($programa->imagen); ?>" alt="" width="100">
                    </td>
                    <td>
                        
                        <?php if($programa->estadoPrograma == 'Activo'): ?>
                            <span class="badge badge-success"><?php echo e($programa->estadoPrograma); ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger"><?php echo e($programa->estadoPrograma); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('programas.edit', ['programa'=>$programa])); ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button class="btn btn-danger" wire:click="delete(<?php echo e($programa->id); ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                        <a href="<?php echo e(route('verlista', $programa->id)); ?>" class="btn btn-warning">
                            <i class="fas fa-graduation-cap"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">
                        <div class="alert alert-danger">
                            No hay registros
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <?php echo e($programas->links()); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/livewire/programas-live.blade.php ENDPATH**/ ?>