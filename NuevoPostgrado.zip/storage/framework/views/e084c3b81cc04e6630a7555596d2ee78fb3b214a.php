<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('plugins.Summernote', true); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Bienvenido al panel de control de la Dirección de <span class="text-danger">Postgrado</span> <span class="text-primary">U.A.T.F.</span></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center">
        
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($administradores).'','text' => 'Administradores','icon' => 'fas fa-fw fa-user-shield','theme' => 'primary','url' => ''.e(route('administradores.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($coordinadores).'','text' => 'Coordinadores','icon' => 'fas fa-fw fa-user-tie','theme' => 'secondary','url' => ''.e(route('coordinadores.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($estudiantes).'','text' => 'Estudiantes Registrados','icon' => 'fas fa-user-plus','theme' => 'warning','url' => '#','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>

    </div>
    <div class="row d-flex justify-content-center">
        
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($universidades).'','text' => 'UNIVERSIDADES','icon' => 'fas fa-fw fa-university','theme' => 'dark','url' => ''.e(route('universidades.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($facultades).'','text' => 'FACULTADES','icon' => 'fas fa-fw fa-graduation-cap','theme' => 'info','url' => ''.e(route('facultades.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
            
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($carreras).'','text' => 'CARRERAS','icon' => 'fas fa-fw fa-book','theme' => 'purple','url' => ''.e(route('carreras.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>

    <div class="row d-flex justify-content-center">
        
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($tipoprogramas).'','text' => 'TIPOS DE PROGRAMAS','icon' => 'fas fa-fw fa-graduation-cap','theme' => 'danger','url' => ''.e(route('tipoprogramas.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($convenios).'','text' => 'CONVENIOS','icon' => 'fas fa-fw fa-handshake','theme' => 'light','url' => ''.e(route('convenios.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
            
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::resolve(['title' => ''.e($programas).'','text' => 'PROGRAMAS','icon' => 'fas fa-fw fa-book','theme' => 'teal','url' => ''.e(route('programas.index')).'','urlText' => 'Ver mas...'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-3 mx-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/home.blade.php ENDPATH**/ ?>