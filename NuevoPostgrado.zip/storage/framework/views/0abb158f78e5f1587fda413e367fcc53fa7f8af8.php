

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('plugins.Summernote', true); ?>
<?php $__env->startSection('content_header'); ?>
    
    <div class="container">
        <h1>Crear Programas</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php
    $config = [
        "height" => "300",
        "toolbar" => [
            // [groupName, [list of button]]
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['fontsize', ['fontsize']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['height', ['height']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', 'codeview', 'help']],
        ],
    ]
    ?>
    <form action="<?php echo e(route('programas.update',['programa'=>$programa])); ?>" method="POST" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row my-2">
            <div class="col-4">
                <label for="tipoPrograma">TIPO DE PROGRAMA</label>
                <select name="tipoPrograma" id="tipoPrograma" class="form-control">
                    <?php $__currentLoopData = $tipoprogramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoprograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <option 
                            value="<?php echo e($tipoprograma->id); ?>" 
                            <?php echo e($programa->tipoPrograma_id == $tipoprograma->id ? 'selected' : ''); ?>>
                            <?php echo e($tipoprograma->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="facultad">UNIDAD OFERTANTE</label>
                <select name="facultad" id="facultad" class="form-control">
                    <?php $__currentLoopData = $facultades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($facultad->id); ?>" 
                        <?php echo e($programa->facultad_id == $facultad->id ? 'selected' : ''); ?>>
                        <?php echo e($facultad->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="carrera">CARRERA</label>
                <select name="carrera" id="carrera" class="form-control">
                    <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($carrera->id); ?>" 
                        <?php echo e($programa->carrera_id == $carrera->id ? 'selected' : ''); ?>>
                        <?php echo e($carrera->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-4">
                <label for="convenio">CONVENIO</label>
                <select name="convenio" id="convenio" class="form-control">
                    <?php $__currentLoopData = $convenios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $convenio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($convenio->id); ?>"
                        <?php echo e($programa->convenio_id == $convenio->id ? 'selected' : ''); ?>>
                            <?php echo e($convenio->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="nombrePrograma">NOMBRE DEL PROGRAMA</label>
                <input type="text" name="nombrePrograma" id="nombrePrograma" class="form-control" value="<?php echo e($programa->nombrePrograma); ?>">
                <?php $__errorArgs = ['nombrePrograma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="tituloOtorga">TÍTULO QUE OTORGA</label>
                <input type="text" name="tituloOtorga" id="tituloOtorga" class="form-control" value="<?php echo e($programa->tituloOtorga); ?>">
                <?php $__errorArgs = ['tituloOtorga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>



        <div class="row my-2">
            <div class="col-4">
                <label for="modalidad">MODALIDAD</label>
                <input type="text" name="modalidad" id="modalidad" class="form-control" value="<?php echo e($programa->modalidad); ?>">
                <?php $__errorArgs = ['modalidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="cantidadPlazas">CANTIDAD DE PLAZAS</label>
                <input type="text" name="cantidadPlazas" id="cantidadPlazas" class="form-control" value="<?php echo e($programa->cantidadPlazas); ?>">
                <?php $__errorArgs = ['cantidadPlazas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="docentes">DOCENTES</label>
                <input type="text" name="docentes" id="docentes" class="form-control" value="<?php echo e($programa->docentes); ?>">
                <?php $__errorArgs = ['docentes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div class="row my-2">
            <div class="col-4">
                <label for="duracion">DURACIÓN</label>
                <input type="text" name="duracion" id="duracion" class="form-control" value="<?php echo e($programa->duracion); ?>">
                <?php $__errorArgs = ['duracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="horasAcademicas">HORAS ACADÉMICAS</label>
                <input type="text" name="horasAcademicas" id="horasAcademicas" class="form-control" value="<?php echo e($programa->horasAcademicas); ?>">
                <?php $__errorArgs = ['horasAcademicas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="creditos">CRÉDITOS</label>
                <input type="text" name="creditos" id="creditos" class="form-control" value="<?php echo e($programa->creditos); ?>">
                <?php $__errorArgs = ['creditos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row my-2">
            <div class="col-4">
                <label for="horarios">HORARIOS</label>
                <input type="text" name="horarios" id="horarios" class="form-control" value="<?php echo e($programa->horarios); ?>">
                <?php $__errorArgs = ['horarios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="becas">BECAS</label>
                <input type="text" name="becas" id="becas" class="form-control" value="<?php echo e($programa->becas); ?>">
                <?php $__errorArgs = ['becas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="facebook">LINK DEL PROGRAMA DE FACEBOOK</label>
                <input type="text" name="facebook" id="facebook" class="form-control" value="<?php echo e($programa->facebook); ?>">
                <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        
        <div class="row my-2">
            <div class="col-4">
                <label for="instagram">LINK DEL PROGRAMA DE INSTAGRAM</label>
                <input type="text" name="instagram" id="instagram" class="form-control" value="<?php echo e($programa->instagram); ?>">
                <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="twitter">LINK DEL PROGRAMA DE TWITTER</label>
                <input type="text" name="twitter" id="twitter" class="form-control" value="<?php echo e($programa->twitter); ?>">
                <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="whatsapp">LINK DEL GRUPO DE WhatsApp "CONSULTORES" </label>
                <input type="text" name="whatsapp" id="whatsapp" class="form-control" value="<?php echo e($programa->whatsapp); ?>">
                <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div class="row my-2">
            <div class="col-4">
                <label for="consultorwhatsapp">NÚMERO DE WHATSAPP DEL CONSULTOR</label>
                <input type="text" name="consultorwhatsapp" id="consultorwhatsapp" class="form-control" value="<?php echo e($programa->consultorwhatsapp); ?>">
                <?php $__errorArgs = ['consultorwhatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="coordinadorProgramaPostgrado">COORDINADOR DEL PROGRAMA DE POSTGRADO</label>
                
                <select name="coordinadorProgramaPostgrado" id="coordinadorProgramaPostgrado" class="form-control">
                    <?php $__currentLoopData = $coordinadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordinador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($coordinador->id); ?>"
                        <?php echo e($coordinador->id == $programa->coordinador_id? 'selected' : ''); ?>>
                        <?php echo e($coordinador->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="coordinadorPrograma">COORDINADOR DEL PROGRAMA</label>
                <input type="text" name="coordinadorPrograma" id="coordinadorPrograma" class="form-control" value="<?php echo e($programa->coordinadorprograma); ?>">
                <?php $__errorArgs = ['coordinadorPrograma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div class="row my-2">
            <div class="col-4">
                <label for="organizacionCurso">ORGANIZACIÓN DEL CURSO</label>
                <input type="text" name="organizacionCurso" id="organizacionCurso" class="form-control" value="<?php echo e($programa->organizacionCurso); ?>">
                <?php $__errorArgs = ['organizacionCurso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="estadoPrograma">ESTADO DEL PROGRAMA</label>
                
                <select name="estadoPrograma" id="estadoPrograma" class="form-control">
                    <option value="Activo" <?php echo e($programa->estadoPrograma=='Activo'?'selected':''); ?>>ACTIVAR PROGRAMA</option>
                    <option value="Inactivo" <?php echo e($programa->estadoPrograma=='Inactivo'?'selected':''); ?>>DESACTIVAR PROGRAMA</option>
                </select>
            </div>
            <div class="col-4">
                <label for="costoProfesionales">COSTO PARA PROFESIONALES</label>
                <input type="text" name="costoProfesionales" id="costoProfesionales" class="form-control" value="<?php echo e($programa->costoProfesionales); ?>">
                <span class="help-block text-success"><?php echo e(__('Ej.: 4.000 Bs.- (Cuatro mil 00/100 bolivianos)')); ?></span>
                <?php $__errorArgs = ['costoProfesionales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div class="row my-2">
            <div class="col-4">
                <label for="costoEstudiantes">COSTO PARA ESTUDIANTES</label>
                <input type="text" name="costoEstudiantes" id="costoEstudiantes" class="form-control" value="<?php echo e($programa->costoEstudiantes); ?>">
                <span class="help-block text-success"><?php echo e(__('Ej.: 3.500 Bs.- (tres mil Quinientos 00/100 bolivianos)')); ?></span>
                <?php $__errorArgs = ['costoEstudiantes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="primeraCuotaProfesionales">PRIMERA CUOTA PARA PROFESIONALES</label>
                <input type="text" name="primeraCuotaProfesionales" id="primeraCuotaProfesionales" class="form-control" value="<?php echo e($programa->primeraCuotaProfesionales); ?>">
                <span class="help-block text-success"><?php echo e(__('Ej.: 1.200 Bs.-')); ?></span>
                <?php $__errorArgs = ['primeraCuotaProfesionales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="primeraCuotaEstudiantes">PRIMERA CUOTA PARA ESTUDIANTES</label>
                <input type="text" name="primeraCuotaEstudiantes" id="primeraCuotaEstudiantes" class="form-control" value="<?php echo e($programa->primeraCuotaEstudiantes); ?>">
                <span class="help-block text-success"><?php echo e(__('Ej.: 1.000 Bs.-')); ?></span>
                <?php $__errorArgs = ['primeraCuotaEstudiantes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row my-2">
            
            <div class="col-4">
                <label for="pagosMensualesProfesionales">PAGOS MENSUALES PARA PROFESIONALES</label>
                <input type="text" name="pagosMensualesProfesionales" id="pagosMensualesProfesionales" class="form-control" value="<?php echo e($programa->pagosMensualesProfesionales); ?>">
                <span class="help-block text-success"><?php echo e(__('Ej.: 3000 Bs.- en cuatro (4) cuotas mensuales de 700 Bs.-')); ?></span>
                <?php $__errorArgs = ['pagosMensualesProfesionales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="pagosMensualesEstudiantes">PAGOS MENSUALES PARA ESTUDIANTES</label>
                <input type="text" name="pagosMensualesEstudiantes" id="pagosMensualesEstudiantes" class="form-control" value="<?php echo e($programa->pagosMensualesEstudiantes); ?>">
                <span class="help-block text-success"><?php echo e(__('Ej.: 2000 Bs.- en cuatro (4) cuotas mensuales de 500 Bs.-')); ?></span>
                <?php $__errorArgs = ['pagosMensualesEstudiantes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-4">
                <label for="modalidadDiplomado">¿MODALIDAD VIA DE DIPLOMADO?</label>
                
                <select name="modalidadDiplomado" id="modalidadDiplomado" class="form-control">
                    <option value="SI" <?php echo e($programa->modalidadDiplomado=='SI'?'selected':''); ?>>SI (SOLO ESTUDIANTES)</option>
                    <option value="NO" <?php echo e($programa->modalidadDiplomado=='NO'?'selected':''); ?>>NO (SOLO PROFESIONALES)</option>
                    <option value="AMBOS" <?php echo e($programa->modalidadDiplomado=='AMBOS'?'selected':''); ?>>AMBOS (ESTUDIANTES Y PROFESIONALES)</option>
                </select>
            </div>
        </div>

        
        <div class="row my-2">
            <div class="col-12">
                
                <label for="" class="text-danger">Imagen existente--></label>
                <img src="<?php echo e(asset('').'/'.$programa->imagen); ?>" alt="" width="200">
                <br>
                <label for="imagenPostgradoAfiche">INGRESA LA IMAGEN DEL AFICHE (TRATA DE QUE SEA EL MENOR TAMAÑO POSIBLE)</label>
                
                <input type="file" name="imagenPostgradoAfiche" id="imagenPostgradoAfiche" class="form-control">
            </div>
        </div>
        
        <div class="row my-2">
            
            <div class="col-4">
                <label for="objetivos">OBJETIVOS</label>
                
                <textarea name="objetivos" id="objetivos" cols="30" rows="12" class="form-control"><?php echo e($programa->objetivos); ?></textarea>
            </div>
            <div class="col-4">
                <label for="perfilEstudiante">PERFIL DEL ESTUDIANTE</label>
                
                <textarea name="perfilEstudiante" id="perfilEstudiante" cols="30" rows="12" class="form-control"><?php echo e($programa->perfilEstudiante); ?></textarea>
            </div>
            <div class="col-4">
                <label for="presentacion">PRESENTACIÓN</label>
                
                <textarea name="presentacion" id="presentacion" cols="30" rows="12" class="form-control"><?php echo e($programa->presentacion); ?></textarea>
            </div>
        </div>
        
        <div class="row">
            <div class="col-4">
                <label for="perfilGraduado">PERFIL DEL GRADUADO</label>
                
                <textarea name="perfilGraduado" id="perfilGraduado" cols="30" rows="15" class="form-control"><?php echo e($programa->perfilGraduado); ?></textarea>
            </div>
            
            <div class="col-4">
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::resolve(['name' => 'planEstudio','label' => 'PLAN DE ESTUDIO','labelClass' => 'text-dark','igroupSize' => 'sm','config' => $config] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Ingrese el plan de estudio...']); ?>
                    <?php echo $programa->planEstudio; ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b)): ?>
<?php $component = $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b; ?>
<?php unset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::resolve(['name' => 'cronograma','label' => 'CRONOGRAMA','labelClass' => 'text-dark','igroupSize' => 'sm','config' => $config] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Ingrese el cronograma...']); ?>
                    <?php echo $programa->cronograma; ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b)): ?>
<?php $component = $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b; ?>
<?php unset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::resolve(['name' => 'requisitos','label' => 'REQUISITOS','labelClass' => 'text-dark','igroupSize' => 'sm','config' => $config] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Ingrese los requisitos...']); ?>
                    <?php echo $programa->requisitos; ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b)): ?>
<?php $component = $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b; ?>
<?php unset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::resolve(['name' => 'mayoresInformes','label' => 'MAYORES INFORMES','labelClass' => 'text-dark','igroupSize' => 'sm','config' => $config] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Ingrese los mayores informes...']); ?>
                    <?php echo $programa->mayoresInformes; ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b)): ?>
<?php $component = $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b; ?>
<?php unset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::resolve(['name' => 'inversion','label' => 'INVERSION','labelClass' => 'text-dark','igroupSize' => 'sm','config' => $config] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\TextEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Ingrese la inversión']); ?>
                    <?php echo $programa->inversion; ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b)): ?>
<?php $component = $__componentOriginal870352fc7c90c56215c133737b8334084cd6753b; ?>
<?php unset($__componentOriginal870352fc7c90c56215c133737b8334084cd6753b); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <button class="btn btn-success mb-4">GUARDAR PROGRAMA</button>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NuevoPostgrado\resources\views/programas/edit.blade.php ENDPATH**/ ?>