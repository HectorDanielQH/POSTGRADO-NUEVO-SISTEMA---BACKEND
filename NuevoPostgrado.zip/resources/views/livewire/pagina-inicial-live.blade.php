<div>
    {{--banner mensaje de letras bootstrap--}}
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-4" style="color: rgba(252, 250, 250, 0.938)">Bienvenido al Panel de Control de la <br> <span style="color: rgb(0, 131, 192)"> DIRECCIÓN DE POSTGRADO</span> <span style="color: rgb(192, 0, 0)">U.A.T.F.</span> </h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
