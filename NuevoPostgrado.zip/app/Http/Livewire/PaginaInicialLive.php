<?php

namespace App\Http\Livewire;

use Livewire\Component;

class PaginaInicialLive extends Component
{
    public function render()
    {
        return view('livewire.pagina-inicial-live');
    }
}
