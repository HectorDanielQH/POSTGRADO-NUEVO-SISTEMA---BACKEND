<?php return array (
  'administradores-live' => 'App\\Http\\Livewire\\AdministradoresLive',
  'carreras-live' => 'App\\Http\\Livewire\\CarrerasLive',
  'convenios-live' => 'App\\Http\\Livewire\\ConveniosLive',
  'coordinadores-live' => 'App\\Http\\Livewire\\CoordinadoresLive',
  'facultades-live' => 'App\\Http\\Livewire\\FacultadesLive',
  'pagina-inicial-live' => 'App\\Http\\Livewire\\PaginaInicialLive',
  'programas-live' => 'App\\Http\\Livewire\\ProgramasLive',
  'tipoprogramas-live' => 'App\\Http\\Livewire\\TipoprogramasLive',
  'universidades-live' => 'App\\Http\\Livewire\\UniversidadesLive',
);